# Content-Delivery-Server
A lightweight Express.js server that serves static HTML, CSS, and JavaScript files while logging user visits. It features a /logs API to retrieve visit data in JSON format and provides an option to download the visit log file. Perfect for basic content delivery and logging user interactions.
